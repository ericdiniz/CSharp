﻿namespace MeuSiteEmMVC.Models
{
    public class HomeModel
    {
        public string nome { get; set; }
        public string email { get; set; }
    }
}
